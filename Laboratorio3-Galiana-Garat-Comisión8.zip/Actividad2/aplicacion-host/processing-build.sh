rm -rf build
processing-java --sketch="SE_Lab_HostTempApp" --output="build" --export 
